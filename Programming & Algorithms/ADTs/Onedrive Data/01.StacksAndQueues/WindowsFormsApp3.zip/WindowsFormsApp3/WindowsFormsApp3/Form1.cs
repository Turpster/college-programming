﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;




namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        Label[] myArray = new Label[4];
        int top = 0;
        int max = 4;
        




        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            myArray[1] = label1;
            myArray[2] = label2;
            myArray[3] = label3;
            myArray[4] = label4;


        }

        private void btnPush_Click(object sender, EventArgs e)
        {

        }
    }
}

